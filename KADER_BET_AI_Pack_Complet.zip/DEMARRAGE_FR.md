# KADER BET AI — étape de connexion

Cette livraison contient un backend de démonstration connecté à API-Sports lorsque vous fournissez une clé valide, ainsi que le prototype Android livré précédemment.

## Ce qui est utilisable
- Backend REST démarrable sur un ordinateur/serveur.
- Lecture des matchs du jour depuis API-Football.
- Première estimation probabiliste par modèle de Poisson sur les derniers résultats.
- Documentation interactive FastAPI.

## Ce qui manque encore avant une vraie application quotidienne
1. Une clé API-Sports active et un forfait couvrant les compétitions souhaitées.
2. Un serveur HTTPS permanent (VPS ou hébergement cloud).
3. Le raccordement de l'application Android à l'URL publique du backend.
4. Une source de cotes en temps réel et une calibration/validation du modèle.
5. Des tests historiques (backtesting) et suivi du rendement avant toute utilisation avec argent réel.

La connexion et le placement automatique sur 1XBET ne sont pas inclus. Le ticket doit être vérifié et validé manuellement, et toute intégration doit être explicitement autorisée par 1XBET.

## Ne pas confondre
Un backend qui démarre n'est pas une IA gagnante. Le modèle actuel est une base statistique expérimentale. Il peut se tromper et ne garantit aucun bénéfice.
