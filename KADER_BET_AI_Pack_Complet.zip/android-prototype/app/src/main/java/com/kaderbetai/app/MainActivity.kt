package com.kaderbetai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF10141D)
private val Panel = Color(0xFF1B2230)
private val Gold = Color(0xFFE0B65B)
private val Muted = Color(0xFF9AA5B5)
private val Green = Color(0xFF58C69A)
private val Red = Color(0xFFE87979)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KaderBetApp() }
    }
}

@Composable
fun KaderBetApp() {
    var tab by remember { mutableStateOf("Accueil") }
    var capital by remember { mutableStateOf("200") }
    var stake by remember { mutableStateOf("5") }
    var accepted by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Gold,
        onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Gold) {
                    listOf("Accueil", "Matchs", "Tickets", "Capital").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(
                                    when(item) {
                                        "Matchs" -> Icons.Default.SportsSoccer
                                        "Tickets" -> Icons.Default.ReceiptLong
                                        "Capital" -> Icons.Default.AccountBalanceWallet
                                        else -> Icons.Default.Dashboard
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold, selectedTextColor = Gold,
                                indicatorColor = Ink, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when(tab) {
                "Matchs" -> MatchesScreen(Modifier.padding(padding))
                "Tickets" -> TicketsScreen(stake, { stake = it }, accepted, { accepted = it }, Modifier.padding(padding))
                "Capital" -> CapitalScreen(capital, { capital = it }, Modifier.padding(padding))
                else -> HomeScreen(capital, Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun Header(subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 18.dp)) {
        Text("KADER BET AI", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun HomeScreen(capital: String, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(20.dp)) {
        item {
            Header("INTELLIGENCE FOOTBALL • VERSION 1.0")
            CardBlock {
                Text("TABLEAU DE BORD", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Text("$capital FD", color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text("Capital de référence • modifiable", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Metric("Tickets du jour", "0")
                    Metric("Gain net", "0 FD")
                    Metric("Risque", "Contrôlé")
                }
            }
            Spacer(Modifier.height(16.dp))
            CardBlock {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Gold)
                    Spacer(Modifier.width(8.dp))
                    Text("MOTEUR D'ANALYSE", fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Text("Le moteur évaluera forme récente, domicile/extérieur, buts, absences, confrontations et cotes dès qu'une source de données sera configurée.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                StatusLine("Données en direct", "Non connectées", Red)
                StatusLine("Connexion 1XBET", "Non configurée", Red)
                StatusLine("Validation humaine", "Obligatoire", Green)
            }
            Spacer(Modifier.height(16.dp))
            CardBlock {
                Text("RÈGLE DE SÉCURITÉ", color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Aucun pari n'est garanti. Le système doit pouvoir recommander : NE PAS PARIER. Ne jamais augmenter une mise pour récupérer une perte.", color = Muted, fontSize = 13.sp)
            }
            Spacer(Modifier.height(12.dp))
            Text("Prototype : les éléments affichés ne sont pas des pronostics réels.", color = Gold, fontSize = 11.sp)
        }
    }
}

@Composable
fun MatchesScreen(modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(20.dp)) {
        item {
            Header("MATCHS & ANALYSES")
            CardBlock {
                Text("AUCUN FLUX DE MATCHS CONNECTÉ", color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Cette version de démarrage utilise des données de démonstration uniquement. Pour afficher les rencontres réelles, il faudra connecter un fournisseur de données football et une clé API.", color = Muted, fontSize = 13.sp)
            }
            Spacer(Modifier.height(14.dp))
            Text("CHAMPS ANALYSÉS", color = Gold, fontWeight = FontWeight.Bold)
            listOf("10 derniers matchs", "Performances domicile / extérieur", "Buts marqués et encaissés", "Blessures et suspensions", "Confrontations directes", "Probabilités 1X2 et buts", "Cote du bookmaker et valeur estimée").forEach {
                CardBlock { Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, null, tint = Green, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(9.dp)); Text(it, fontSize = 13.sp)
                } }
                Spacer(Modifier.height(7.dp))
            }
        }
    }
}

@Composable
fun TicketsScreen(stake: String, onStake: (String) -> Unit, accepted: Boolean, onAccepted: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(20.dp)) {
        item {
            Header("CONSTRUCTION DES TICKETS")
            CardBlock {
                Text("TICKET DE DÉMONSTRATION", color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Sélection : à définir après analyse des matchs réels", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = stake, onValueChange = onStake,
                    label = { Text("Mise envisagée (FD)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                Text("Aucune cote ni aucun gain ne sont simulés sans données réelles.", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = accepted, onCheckedChange = onAccepted, colors = CheckboxDefaults.colors(checkedColor = Gold))
                    Text("Je confirme que toute mise comporte un risque.", fontSize = 12.sp, color = Muted)
                }
                Button(
                    onClick = { onAccepted(false) },
                    enabled = accepted && (stake.toDoubleOrNull() ?: 0.0) > 0,
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("VALIDATION DE PRINCIPE (SANS PARI)") }
            }
            Spacer(Modifier.height(12.dp))
            Text("Le placement réel restera manuel, après vérification sur 1XBET.", color = Gold, fontSize = 12.sp)
        }
    }
}

@Composable
fun CapitalScreen(capital: String, onCapital: (String) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(20.dp)) {
        item {
            Header("GESTION DU CAPITAL")
            CardBlock {
                Text("CAPITAL DISPONIBLE", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = capital, onValueChange = onCapital,
                    label = { Text("Capital en francs djiboutiens (FD)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                Text("Repère prudent : une mise faible et fixe, définie à l'avance. Le capital peut être perdu intégralement.", color = Muted, fontSize = 13.sp)
            }
            Spacer(Modifier.height(14.dp))
            CardBlock {
                Text("SUIVI FINANCIER", color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                StatusLine("Capital initial", "$capital FD", Green)
                StatusLine("Mises cumulées", "0 FD", Muted)
                StatusLine("Résultat net", "0 FD", Muted)
                StatusLine("Historique", "À alimenter", Muted)
            }
        }
    }
}

@Composable
fun CardBlock(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), content = content)
    }
}
@Composable
fun Metric(label: String, value: String) {
    Column {
        Text(label, color = Muted, fontSize = 10.sp)
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}
@Composable
fun StatusLine(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Muted, fontSize = 12.sp)
        Text(value, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
