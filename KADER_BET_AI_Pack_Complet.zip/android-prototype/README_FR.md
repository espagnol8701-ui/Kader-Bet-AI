# KADER BET AI – Prototype Android 1.0

Application Android native (Kotlin + Jetpack Compose), interface française, thème sombre/noir et or.

## Contenu actuel
- Tableau de bord
- Écrans Matchs, Tickets et Capital
- Capital personnalisable en FD
- Validation humaine mise en avant
- Aucune fausse donnée présentée comme pronostic réel

## Limites importantes
Cette archive est un **prototype de démarrage**, pas encore une application connectée aux données en direct.
Elle ne contient pas de clé API, ne récupère pas les cotes et ne se connecte pas à un compte 1XBET.
Le placement de paris n'est pas automatisé. Toute intégration doit respecter les conditions officielles du bookmaker et les règles applicables à Djibouti.
Aucun système ne peut garantir un gain à chaque pari.

## Ouvrir et compiler
1. Installer Android Studio sur un ordinateur.
2. Ouvrir le dossier `KaderBetAI_Android` avec Android Studio.
3. Laisser Gradle synchroniser les dépendances.
4. Choisir `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
5. L'APK de test sera généralement créé dans `app/build/outputs/apk/debug/`.

Configuration minimale : Android Studio récent, JDK 17, Android SDK 35.
Téléphone cible : Android 8.0 ou supérieur.

## Étape suivante pour la version connectée
- Choisir un fournisseur de données football et son forfait.
- Créer un backend sécurisé pour conserver les clés API (ne jamais les mettre dans l'APK).
- Connecter fixtures, résultats, statistiques, compositions et cotes selon la couverture du fournisseur.
- Ajouter un moteur probabiliste transparent, historique des prédictions et suivi des performances.
- Ajouter un flux de préparation de ticket avec confirmation manuelle. Ne pas automatiser les mises via méthodes non autorisées.
