# Backend KADER BET AI (prototype connecté)

API REST FastAPI utilisant API-Sports / API-Football.

## Lancer localement
1. Python 3.10+.
2. `python -m venv .venv`
3. Activer l'environnement virtuel.
4. `pip install -r requirements.txt`
5. Copier `.env.example` vers `.env` et renseigner `APISPORTS_KEY`.
6. `uvicorn app:app --host 0.0.0.0 --port 8000`

Documentation interactive : `/docs` ; état : `/health`.

## Endpoints
- `GET /health`
- `GET /leagues`
- `GET /fixtures?day=2026-11-18&league_id=39&season=2026`
- `GET /analyze/{fixture_id}`

## Sécurité et limites
- La clé API reste exclusivement sur le serveur, jamais dans l'APK.
- Ne pas exposer le serveur directement sans HTTPS, authentification, limitation de débit et journalisation.
- L'analyse actuelle est un modèle Poisson simplifié basé sur l'historique récent. Elle n'intègre pas les blessures, compositions, cotes, ni les données tactiques.
- Le fournisseur et le forfait doivent couvrir les ligues, saisons et quotas voulus. Les identifiants de ligue et saisons doivent être vérifiés dans le compte fournisseur.
- L'API ne place aucun pari et ne se connecte pas au compte 1XBET.
