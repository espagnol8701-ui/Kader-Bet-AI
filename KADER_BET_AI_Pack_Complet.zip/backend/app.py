import os, math
from datetime import date
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

load_dotenv()
API_KEY = os.getenv("APISPORTS_KEY", "").strip()
API_BASE = os.getenv("API_BASE_URL", "https://v3.football.api-sports.io").rstrip("/")
ORIGINS = [x.strip() for x in os.getenv("CORS_ORIGINS", "*").split(",")]

app = FastAPI(title="KADER BET AI API", version="1.0.0",
              description="Analyse statistique probabiliste. Aucun pari n'est garanti.")
app.add_middleware(CORSMiddleware, allow_origins=ORIGINS, allow_credentials=False,
                   allow_methods=["GET"], allow_headers=["*"])

LEAGUES = {
    "Premier League": 39, "La Liga": 140, "Bundesliga": 78,
    "Serie A": 135, "Ligue 1": 61, "Eredivisie": 88,
    "Primeira Liga": 94, "Champions League": 2, "Europa League": 3,
    "Conference League": 848, "Africa Cup of Nations":  আফ
}


def require_key():
    if not API_KEY or API_KEY == "PUT_YOUR_API_KEY_HERE":
        raise HTTPException(503, "Clé API-Sports absente. Configurez APISPORTS_KEY dans le fichier .env du serveur.")

async def provider_get(path: str, params: dict):
    require_key()
    headers = {"x-apisports-key": API_KEY}
    async with httpx.AsyncClient(timeout=20) as client:
        try:
            response = await client.get(f"{API_BASE}/{path.lstrip('/')}", params=params, headers=headers)
            response.raise_for_status()
            payload = response.json()
        except httpx.HTTPError as exc:
            raise HTTPException(502, f"Erreur fournisseur de données: {str(exc)}")
    if payload.get("errors"):
        raise HTTPException(502, f"Erreur API-Sports: {payload['errors']}")
    return payload.get("response", [])

@app.get("/health")
def health():
    return {"status": "ok", "service": "KADER BET AI", "provider_key_configured": bool(API_KEY)}

@app.get("/leagues")
def leagues():
    return [{"name": k, "id": v} for k, v in LEAGUES.items()]

@app.get("/fixtures")
async def fixtures(day: date = Query(default_factory=date.today),
                   league_id: Optional[int] = None, season: Optional[int] = None):
    params = {"date": day.isoformat()}
    if league_id:
        params["league"] = league_id
        params["season"] = season or day.year
    rows = await provider_get("fixtures", params)
    return [{
        "fixture_id": x["fixture"]["id"],
        "date": x["fixture"]["date"],
        "status": x["fixture"]["status"]["short"],
        "league": x["league"]["name"],
        "country": x["league"]["country"],
        "home": x["teams"]["home"]["name"],
        "away": x["teams"]["away"]["name"],
        "home_id": x["teams"]["home"]["id"],
        "away_id": x["teams"]["away"]["id"],
        "goals": x.get("goals")
    } for x in rows]

def poisson_probs(lam: float, max_goals: int = 8):
    probs = [math.exp(-lam) * lam**k / math.factorial(k) for k in range(max_goals + 1)]
    total = sum(probs)
    return [p / total for p in probs]

def score_model(home_avg: float, away_avg: float):
    hp, ap = poisson_probs(max(0.15, min(home_avg, 4.0))), poisson_probs(max(0.15, min(away_avg, 4.0)))
    p1 = px = p2 = over25 = btts = 0.0
    scorelines = []
    for h, ph in enumerate(hp):
        for a, pa in enumerate(ap):
            p = ph * pa
            if h > a: p1 += p
            elif h == a: px += p
            else: p2 += p
            if h + a >= 3: over25 += p
            if h > 0 and a > 0: btts += p
            scorelines.append((p, h, a))
    scorelines.sort(reverse=True)
    return {
        "home_win": round(p1 * 100, 1), "draw": round(px * 100, 1),
        "away_win": round(p2 * 100, 1), "over_2_5": round(over25 * 100, 1),
        "under_2_5": round((1-over25) * 100, 1),
        "btts_yes": round(btts * 100, 1), "btts_no": round((1-btts) * 100, 1),
        "top_scores": [{"score": f"{h}-{a}", "probability": round(p*100, 1)} for p,h,a in scorelines[:5]]
    }

async def team_recent(team_id: int, season: int):
    rows = await provider_get("fixtures", {"team": team_id, "last": 10, "season": season, "status": "FT"})
    scored, conceded = [], []
    for x in rows:
        goals = x.get("goals") or {}
        home_id = x["teams"]["home"]["id"]
        if team_id == home_id:
            scored.append(goals.get("home") or 0); conceded.append(goals.get("away") or 0)
        else:
            scored.append(goals.get("away") or 0); conceded.append(goals.get("home") or 0)
    if len(scored) < 5:
        raise HTTPException(422, f"Historique insuffisant pour l'équipe {team_id}: {len(scored)} matchs trouvés.")
    return sum(scored)/len(scored), sum(conceded)/len(conceded), len(scored)

@app.get("/analyze/{fixture_id}")
async def analyze(fixture_id: int):
    rows = await provider_get("fixtures", {"id": fixture_id})
    if not rows:
        raise HTTPException(404, "Match introuvable.")
    f = rows[0]
    if f["fixture"]["status"]["short"] not in ("NS", "TBD"):
        raise HTTPException(422, "L'analyse pré-match n'est disponible que pour un match non commencé.")
    home_id, away_id = f["teams"]["home"]["id"], f["teams"]["away"]["id"]
    season = f["league"].get("season") or int(f["fixture"]["date"][:4])
    hs, hc, hn = await team_recent(home_id, season)
    ass, ac, an = await team_recent(away_id, season)
    # Estimate goals from attack/defence rates with a modest home advantage.
    league_home = max(0.5, (hs + ac) / 2)
    league_away = max(0.4, (ass + hc) / 2)
    home_lambda = max(0.2, min(3.5, (hs + ac) / 2 * 1.08))
    away_lambda = max(0.2, min(3.5, (ass + hc) / 2 * 0.92))
    probs = score_model(home_lambda, away_lambda)
    return {
        "fixture_id": fixture_id,
        "match": f'{f["teams"]["home"]["name"]} - {f["teams"]["away"]["name"]}',
        "kickoff": f["fixture"]["date"], "league": f["league"]["name"],
        "sample": {"home_recent_matches": hn, "away_recent_matches": an},
        "expected_goals": {"home": round(home_lambda, 2), "away": round(away_lambda, 2)},
        "probabilities_percent": probs,
        "method": "Poisson simplifié basé sur les buts des 10 derniers matchs disponibles",
        "limitations": [
            "Modèle indicatif non calibré : ne tient pas encore compte des blessures, compositions, météo, motivation ou cotes.",
            "Les probabilités sont des estimations et ne constituent pas une garantie de gain."
        ],
        "recommendation": "NE PAS PARIER automatiquement tant que les cotes réelles et les facteurs contextuels ne sont pas vérifiés."
    }
